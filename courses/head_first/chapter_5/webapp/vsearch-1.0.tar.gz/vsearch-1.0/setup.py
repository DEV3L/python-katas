from setuptools import setup

setup (
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='Justin Beall',
    author_email='jus.beall@gmail.com',
    url='https://twitter.com/dev3l_',
    py_modules=['vsearch'],
)
