./python3 setup.py sdist

workon python_katas

pip install ./dist/vsearch-1.0.tar.gz
